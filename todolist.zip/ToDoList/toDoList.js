
const text = "By Amal.";
const speed = 200;
let i = 0;

function typeWriter() {
    if (i < text.length) {
        document.getElementById("typewriter").innerHTML += text.charAt(i);
        i++;
        setTimeout(typeWriter, speed);
    }
}

window.onload = typeWriter;
const toDoBtn = document.querySelector(".todo-btn")
const toDoInput = document.querySelector('.todo-input');
const taskList = document.querySelector('.tasklist');



toDoBtn.addEventListener('click', (event) => {
    event.preventDefault();
    const taskText = toDoInput.value.trim(); // Trim whitespace from the input
    if (taskText === '') {
        alert('Please enter a task.');
        return;
    }

    const newTask = document.createElement('li');

    newTask.classList.add('task', 'bg-white', 'text-darkPink', 'hover:bg-pink-300', 'font-bold', 'rounded-full', 'border-b', 'flex', 'items-center', 'justify-between', 'space-x-6', 'p-2', 'px-12', 'pr-12', 'space-x-6',);


    const taskContent = document.createElement('span');
    taskContent.textContent = taskText; // Set the text to the task text
    taskContent.classList.add('flex-grow', 'text-left');

    newTask.appendChild(taskContent);
    const checkButton = document.createElement('button');
    checkButton.className = 'check-btn';
    const checkImage = document.createElement('img');
    checkImage.src = 'images/check.png';
    checkImage.alt = 'Check';
    checkImage.className = 'w-6 h-6';
    checkButton.appendChild(checkImage);

    checkButton.addEventListener('click', () => {
        newTask.classList.toggle('line-through'); // Toggle the line-through class on the specific task
        if (checkImage.src.includes('check.png')) {
            checkImage.src = 'images/checked.png'; // Change to checked image
        } else {
            checkImage.src = 'images/check.png'; // Change back to original image
        }
    });


    showTaskAddingDiv()


    const deleteButton = document.createElement('button');
    deleteButton.className = 'delete-btn ml-2';
    const deleteImage = document.createElement('img');
    deleteImage.src = 'images/delete.png';
    deleteImage.alt = 'Delete';
    deleteImage.className = 'w-6 h-6';
    deleteButton.appendChild(deleteImage);


    deleteButton.addEventListener('click', () => {
        taskList.removeChild(newTask);
        checkAndHideTaskDiv();
    });

    newTask.appendChild(checkButton);
    newTask.appendChild(deleteButton);

    document.querySelector('.todo-input').value = '';
    taskList.appendChild(newTask);

});
function showTaskAddingDiv() {
    const div = document.getElementById('taskDiv');
    div.classList.remove('hidden');
}


function checkAndHideTaskDiv() {
    if (taskList.children.length === 0) {
        taskDiv.classList.add('hidden');
    }
}







